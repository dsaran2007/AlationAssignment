$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resource/alation.feature");
formatter.feature({
  "line": 1,
  "name": "Alation Assignment",
  "description": "",
  "id": "alation-assignment",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Get the book details from amazon",
  "description": "",
  "id": "alation-assignment;get-the-book-details-from-amazon",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "Launch Amazon website \"https://www.amazon.com/\"",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "Select \"Books\" from the category",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "Search for \"data catalog\"",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "Open the first result of the page",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Record details of that product",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Close the browser",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "https://www.amazon.com/",
      "offset": 23
    }
  ],
  "location": "StepDefinitions.launch_Amazon_website(String)"
});
formatter.result({
  "duration": 21903841202,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Books",
      "offset": 8
    }
  ],
  "location": "StepDefinitions.select_from_the_category(String)"
});
formatter.result({
  "duration": 12420128445,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "data catalog",
      "offset": 12
    }
  ],
  "location": "StepDefinitions.search_for(String)"
});
formatter.result({
  "duration": 6006828700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitions.open_the_first_result_of_the_page()"
});
formatter.result({
  "duration": 5347143745,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitions.record_details_of_that_product()"
});
formatter.result({
  "duration": 16773676059,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitions.close_the_browser()"
});
formatter.result({
  "duration": 226235305,
  "status": "passed"
});
});