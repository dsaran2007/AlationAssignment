package Alation.Assignment;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		strict = false,
		features = {"src/test/resource/alation.feature"},
		plugin = {"pretty", "html:Reports/cucumber", "json:Reports/cucumber/cucumber.json"},
		glue = {"Alation.Assignment"}
		
		)
		
public class AppTest 
    
{
   
}