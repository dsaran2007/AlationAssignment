package Alation.Assignment;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitions {
	
	WebDriver driver;
	
	// Load the properties repository file		
	Properties obj = new Properties();	
	
	@Given("^Launch Amazon website \"([^\"]*)\"$")
	public void launch_Amazon_website(String URL) throws Throwable {
		
		System.setProperty("webdriver.chrome.driver", "E:\\Selenium\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		//System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\Driver\\geckodriver.exe");
		//driver = new FirefoxDriver();
		
		//Deleting the cookies before proceeding with test execution
		driver.manage().deleteAllCookies();
		
		//Maximizing the window
		driver.manage().window().maximize();
		
		//Page load wait of the page
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		//Launching amazon website
		driver.navigate().to(URL);
		
	}

	@When("^Select \"([^\"]*)\" from the category$")
	public void select_from_the_category(String book) throws Throwable {

		//Accessing the object repository
		FileInputStream objfile = new FileInputStream(System.getProperty("user.dir")+"\\Repository.properties");
		obj.load(objfile);	
		
		// Selecting Books from the category
		Select dropDown = new Select(driver.findElement(By.id(obj.getProperty("dropdown"))));
		dropDown.selectByVisibleText(book);
		
	}

	@And("^Search for \"([^\"]*)\"$")
	public void search_for(String search) throws Throwable {

		//Entering the search item and clicking on search button
		driver.findElement(By.id(obj.getProperty("textarea"))).sendKeys(search);
		driver.findElement(By.xpath(obj.getProperty("search"))).click();
	    
	}

	@And("^Open the first result of the page$")
	public void open_the_first_result_of_the_page() throws Throwable {

		//Clicking on the first item of the search result
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[4]/div[1]/div[1]/ul[1]/li[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/h2[1]")).click();
	    
	}

	@Then("^Record details of that product$")
	public void record_details_of_that_product() throws Throwable {

		//Printing Book Title and Book Edition
		String BookTitle = driver.findElement(By.xpath(obj.getProperty("booktitle"))).getText();
		String BookEdition = driver.findElement(By.xpath(obj.getProperty("bookedition"))).getText();
		System.out.println(BookTitle + " | " + BookEdition);
		
		//Printing Paperback Price details
		String PaperbackNewPrice = driver.findElement(By.xpath(obj.getProperty("paperbacknewprice"))).getText();
		Thread.sleep(3000);
		String DeliveryMsg = driver.findElement(By.xpath(obj.getProperty("deliverymsg"))).getText();
		Thread.sleep(3000);
		driver.findElement(By.xpath(obj.getProperty("buyused"))).click();
		String PaperbackUsedPrice = driver.findElement(By.xpath(obj.getProperty("paperbackusedprice"))).getText();
		System.out.println("Price of new book is " + PaperbackNewPrice);
		System.out.println(DeliveryMsg);
		System.out.println("Price of used book is "  + PaperbackUsedPrice);
		
		//Printing Kindle Price details
		driver.findElement(By.xpath(obj.getProperty("kindlelink"))).click();
		String KindlePrice = driver.findElement(By.xpath(obj.getProperty("kindleprice"))).getText();
		System.out.println("Price of book in kindle is " + KindlePrice);
		
		
		//Printing Other Seller Price details
		driver.findElement(By.xpath(obj.getProperty("othersellerslink"))).click();
		String OtherSellerKindlePrice = driver.findElement(By.xpath(obj.getProperty("othersellerkindleprice"))).getText();
		String OtherSellerPaperbackPrice = driver.findElement(By.xpath(obj.getProperty("othersellerpaperbackprice"))).getText();
		System.out.println("Price of Other Seller Kindle book is " + OtherSellerKindlePrice);
		System.out.println("Price of Other Seller Paperback book is "  + OtherSellerPaperbackPrice);
		
		//Scroll into Product details section
		
		WebElement element = driver.findElement(By.id(obj.getProperty("productdetails")));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		Thread.sleep(3000); 
		
		//Printing Product Details
		String ProductDetails = driver.findElement(By.id(obj.getProperty("productdetails"))).getText();
		System.out.println(ProductDetails);
		
	}

	@And("^Close the browser$")
	public void close_the_browser() throws Throwable {
		//Closing the browser
		driver.close();
	    
	}

}